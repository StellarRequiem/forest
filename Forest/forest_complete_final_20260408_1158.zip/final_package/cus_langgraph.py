#!/usr/bin/env python3
"""
Forest CUS LangGraph v4.1 — NetworkWatcher integrated as native Lvl1 organ
"""

import time
import uuid
from pathlib import Path
from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

try:
    from enforcer import enforcer
except ImportError:
    class DummyEnforcer:
        def scan_swarm(self, status=None): return {"status": "scanned"}
        def approve(self, action): return True
        def enforce_constitution(self, output): return True
    enforcer = DummyEnforcer()

try:
    from lvl1_worker import NetworkWatcher, TelemetryGuardian
    print("✅ NetworkWatcher + TelemetryGuardian loaded as native Lvl1 organs")
except ImportError as e:
    print(f"⚠️ {e}")

class CUSState(TypedDict):
    task: str
    level: int
    understory_results: Annotated[List[str], "worker outputs"]
    ecosystem_summary: str
    enforcer_approvals: List[str]
    workers_spawned: int
    proposals_stored: int
    idle_mode: bool

def headmaster_node(state: CUSState):
    enforcer.scan_swarm()
    print(f"[HEADMASTER] Delegating task: {state.get('task', 'unknown')}")
    return {"level": 4}

def supervisor_node(state: CUSState):
    action = f"Supervise task: {state.get('task', 'unknown')}"
    print(f"\n🔒 ENFORCER GATE (Supervisor): {action}")
    choice = input("Approve this cycle? (yes/idle) > ").strip().lower()
    if choice == "idle":
        state["idle_mode"] = True
        return {"ecosystem_summary": "IDLE MODE ACTIVATED"}
    if choice in ["yes", "y"]:
        return {"level": 3}
    else:
        return {"ecosystem_summary": "ENFORCER BLOCKED"}

def worker_node(state: CUSState):
    if state.get("idle_mode", False):
        print("[CUS] Idle mode — skipping workers")
        return {"understory_results": [], "ecosystem_summary": "IDLE MODE"}

    print(f"\n[CUS LVL{state['level']}] Understory workers executing...")
    workers = [
        ("network_watcher", "phi3:mini", "Multi-organ network sniffer & anomaly flagging"),
        ("telemetry_guardian", "phi3:mini", "Privacy & telemetry defense"),
        ("log_anomaly_specialist", "phi3:mini", "Log anomaly detection")
    ]
    
    results = []
    for name, model, role in workers:
        print(f"[ENFORCER] Auto-approved safe action → {name}")
        if name == "network_watcher":
            w = NetworkWatcher()
            w.activate()
            res = w.perform_task("Live network snapshot + anomaly flag")
        else:
            res = f"{name}: task completed safely"
        results.append(res)
    
    return {
        "understory_results": results,
        "ecosystem_summary": f"CUS cycle complete — {len(results)} organs processed",
        "workers_spawned": len(workers)
    }

workflow = StateGraph(CUSState)
workflow.add_node("Headmaster", headmaster_node)
workflow.add_node("Supervisor", supervisor_node)
workflow.add_node("Worker", worker_node)
workflow.set_entry_point("Headmaster")
workflow.add_edge("Headmaster", "Supervisor")
workflow.add_edge("Supervisor", "Worker")
workflow.add_edge("Worker", END)

memory = MemorySaver()
cus_graph = workflow.compile(checkpointer=memory)

def run_cus_swarm(level: int = 1, task: str = "Blue-team monitoring cycle"):
    print(f"\n🌲 Starting CUS LangGraph v4.1 with live NetworkWatcher")
    initial_state = {"task": task, "level": level, "understory_results": [], "ecosystem_summary": "", "enforcer_approvals": [], "workers_spawned": 0, "idle_mode": False}
    config = {"configurable": {"thread_id": f"cus-v41-{uuid.uuid4().hex[:8]}"}}
    result = cus_graph.invoke(initial_state, config)
    print("\n=== CUS Cycle Complete ===")
    for r in result.get("understory_results", []):
        print(f"   → {r}")
    return result

if __name__ == "__main__":
    print("=== Forest CUS LangGraph v4.1 Online — NetworkWatcher integrated ===")
    run_cus_swarm()
