#!/usr/bin/env python3
"""
Forest Auto-Runner v1.0 — Runs the full living organism 24/7
Launches CUS cycles every 5 minutes with NetworkWatcher
"""

import time
import sys
from cus_langgraph import run_cus_swarm
from datetime import datetime

print(f"🌲 Forest Auto-Runner started at {datetime.now()}")
print("NetworkWatcher will run automatically every 5 minutes.")
print("Ctrl+C or kill the tmux session to stop.\n")

cycle = 0
while True:
    cycle += 1
    print(f"\n=== AUTO CYCLE {cycle} @ {datetime.now().strftime('%H:%M:%S')} ===")
    try:
        # Auto-approve mode for background operation
        result = run_cus_swarm(level=1, task="Auto blue-team monitoring cycle")
        print(f"   → Cycle complete: {len(result.get('understory_results', []))} organs")
    except KeyboardInterrupt:
        print("\nAuto-runner stopped by user.")
        sys.exit(0)
    except Exception as e:
        print(f"   → Cycle error: {e}")
    time.sleep(300)  # 5 minutes
